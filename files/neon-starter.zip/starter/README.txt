Neon Starter — минимальный шаблон.
Откройте index.html в браузере.
